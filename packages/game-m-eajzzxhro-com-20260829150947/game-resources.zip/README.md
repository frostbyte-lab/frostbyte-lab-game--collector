# Game Resource Package (Game Collector Pro)
Target: https://m.eajzzxhro.com/104/index.html?ot=ca7094186b309ee149c55c8822e7ecf2&l=en&btt=2&or=21novodx%3Dzveuuscmj%3Dxjh&__hv=2fMEQCICuqoNGFMML4fGBdQE%2BkWN6hW4%2FfORGq%2Fnk1ZEMnawwmAiAxGYxJjOCWQZyBSVILpJeMljpfcPHLJNuUZN5itlB12A%3D%3D&__sv=010401YytG6oT6vOl81kKt_NDwR6QjynyruQC7y9kpWiV7QEg%20ko
Tanggal: 2026-08-29T15:09:43.745Z
Total: 9 file (game: 9 · api: 0 · server: 0 · downloadFailed: 0)
Smart rewrite: 2 · frame-buster: 0
Engine: unknown (none)
Analisis: paytable=0 · symbols=0 · features=0 · atlas=0
Collect audit OK: NO / partial · unresolved assets: 4

## Klasifikasi
- Content-Type & ekstensi → **ASSET** (CDN image/audio = asset, bukan API)
- Path session/spin/balance → **API** (terpisah di server/)
- HTTP gagal → **DOWNLOAD_FAILED** (bukan API)
- Auto-spin = Interaction Discovery opsional (default off)

## Pemisahan otomatis
- `assets/` — asset game (symbols, reels, ui, audio, config, ...)
- `server/api/` — snapshot response API
- `collect-audit.json` — post-collect scan http(s) tersisa
- `api-map.json` · `analisis.json` · `KETERANGAN.md`

## Post-collect audit
- Scanned text files: 5
- External URLs found in sources: 11
- HTTPS static asset remaining: 4
- Unresolved static assets: 4
- API/backend (hybrid OK): 0
- Tracking skipped: 0
- Download failed (≠ API): 0
- Offline asset ready (https asset = 0): NO
- Hybrid suggested: NO

### Unresolved assets (sample)
- https://m.eajzzxhro.com/104/J
- https://m.eajzzxhro.com/104/&quot;#motionFilter-0-1788016157726&quot
- https://m.eajzzxhro.com/104/&quot;#motionFilter-1-1788016157726&quot
- https://m.eajzzxhro.com/69e49edf-9e7b-4827-a712-67484138c43d

## Cara pakai
1. Baca **collect-audit.json** + **KETERANGAN.md**
2. Load ZIP di Workspace → Scan Error / AI Repair / Sandbox
3. Hybrid jika API masih butuh server live

> API di folder server/ hanya snapshot saat collect, bukan backend live.
