# KETERANGAN PAKET — Game Collector Pro

**Target:** https://m.eajzzxhro.com/104/index.html?ot=ca7094186b309ee149c55c8822e7ecf2&l=en&btt=2&or=21novodx%3Dzveuuscmj%3Dxjh&__hv=2fMEQCICuqoNGFMML4fGBdQE%2BkWN6hW4%2FfORGq%2Fnk1ZEMnawwmAiAxGYxJjOCWQZyBSVILpJeMljpfcPHLJNuUZN5itlB12A%3D%3D&__sv=010401YytG6oT6vOl81kKt_NDwR6QjynyruQC7y9kpWiV7QEg%20ko
**Dikumpulkan:** 2026-08-29T15:09:43.745Z
**Total resource:** 9
**Smart rewrite:** 2 file · frame-buster: 0

## Pemisahan otomatis

| Kategori | Jumlah | Folder di ZIP |
|----------|--------|---------------|
| Game (asset client) | 9 | `assets/` |
| API (response XHR/fetch) | 0 | `server/api/` |
| Server / config | 0 | `server/` |

## Sub-klasifikasi asset slot (Poin 1)

| Sub-folder | Jumlah |
|------------|--------|
| `assets/images/` | 6 |
| `assets/html/` | 1 |
| `assets/other/` | 1 |
| `assets/js/` | 1 |

## Deteksi engine (Poin 3)

- **Engine:** `unknown`
- **Confidence:** none (score 0)
- **Repair hints:**
  - Use Online Hybrid preview
  - Inspect manifest + analisis.json

## Analisis isi file (Poin 2)

| Temuan | Jumlah |
|--------|--------|
| Engine | unknown (none) |
| JSON ter-parse | 2 |
| Paytable hits | 0 |
| Symbol terdeteksi | 0 |
| Feature hits | 0 |
| Bet / lines config | 0 |
| Atlas / spritesheet | 0 |
| Spine / skel | 0 |
| Audio sprite map | 0 |
| API snapshot | 0 |

Detail lengkap ada di `analisis.json`.

## Host / server yang terdeteksi

### `m.eajzzxhro.com`
- Request: **8**
- Kategori: game
- Contoh URL:
  - https://m.eajzzxhro.com/104/index.html?ot=ca7094186b309ee149c55c8822e7ecf2&l=en&btt=2&or=21novodx%3Dzveuuscmj%3Dxjh&__hv=2fMEQCICuqoNGFMML4fGBdQE%2BkWN6hW4%2FfORGq%2Fnk1ZEMnawwmAiAxGYxJjOCWQZyBSVILpJeMljpfcPHLJNuUZN5itlB12A%3D%3D&__sv=010401YytG6oT6vOl81kKt_NDwR6QjynyruQC7y9kpWiV7QEg%20ko
  - https://m.eajzzxhro.com/loader/04.js
  - https://m.eajzzxhro.com/favicon/favicon-48.png
  - https://m.eajzzxhro.com/favicon/favicon-96.png
  - https://m.eajzzxhro.com/favicon/favicon-192.png

### ``
- Request: **1**
- Kategori: game
- Contoh URL:
  - blob:https://m.eajzzxhro.com/69e49edf-9e7b-4827-a712-67484138c43d

## Endpoint API (snapshot saat collect) — Poin 4

_Tidak ada response API yang tertangkap saat collect._

## Struktur ZIP

```
index.html
assets/
  symbols/          # Symbol / icon slot
  reels/            # Reel graphics
  ui/               # Tombol, panel, HUD
  backgrounds/      # Background scene
  animations/       # Win anim, transition, video
  particles/        # FX / particle
  atlases/          # Sprite atlas / Spine
  audio/            # BGM, SFX, win sounds
  config/           # Paytable, symbol def, features
  js/               # Engine + game logic
  css/ fonts/ images/ html/ data/ other/
server/
  api/              # Snapshot response API
manifest.json
keterangan.json
KETERANGAN.md
README.md
```

## Catatan penting

- Hanya resource yang **dikirim ke browser** saat collect.
- API di folder `server/` adalah **salinan response**, bukan koneksi live.
- Logic server, database, DRM, multiplayer real-time **tidak** ikut.
- Pakai hanya pada game yang kamu miliki / berizin.
